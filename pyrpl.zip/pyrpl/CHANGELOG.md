# PyRPL changelog


## 0.9.5 (November 17, 2020)

- merges the "0.9.3-develop" branch with accumulated upgrades from over 2 years
- last version to support Python 2.7 (though not running tests any more)
- tested on Python 3.6 and 3.7
- significant improvements to IIR filter module