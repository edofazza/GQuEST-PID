
/opt/Xilinx/Vivado/2015.4/settings64.sh
